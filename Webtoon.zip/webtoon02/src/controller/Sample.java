package controller;

import java.io.IOException;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import model.WebtoonDAO;
import model.WebtoonVO;

public class Sample { // 데이터를 긁어와서 저장하는 역할
	public static void main(String[] args) {

		WebtoonDAO WDAO = new WebtoonDAO();

		// public void fucn1() {
		final String url = "https://comic.naver.com/webtoon/weekdayList?week=mon";
		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Elements eles1 = doc.select("#content > div.list_area > ul > li > dl > dt > a"); //제목
		Elements eles2 = doc.select("#content > div.list_area > ul > li > dl > dd.desc > a"); //작가
		
		Iterator<Element> itr1 = eles1.iterator();
		Iterator<Element> itr2 = eles2.iterator();
		while (itr2.hasNext()) {
			WebtoonVO vo = new WebtoonVO();
			String str1 = itr1.next().text();
			String str2 = itr2.next().text();
			vo.setTitle(str1);
			vo.setAuthor(str2);
			WDAO.Insert(vo);
		}
		
	}

}
