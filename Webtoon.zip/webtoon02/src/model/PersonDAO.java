package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PersonDAO {
	Connection conn;
	PreparedStatement pstmt;
	
	final String sql_login ="Select * FROM PERSON WHERE id = ? and password = ?";
	final String sql_signup ="INSERT INTO PERSON(ID, PASSWORD, NAME) VALUES(?,?,?)";
	final String sql_delete = "DELETE FROM PERSON WHERE PERSON=? AND PASSWORD=?";
	public PersonVO Login(PersonVO vo) {// 로그인
		conn = JDBCUtil.connect();
		
		try {
			pstmt = conn.prepareStatement(sql_login);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			ResultSet rs = pstmt.executeQuery();
			PersonVO vo1 = new PersonVO();
			if(rs.next()) {
				vo1.setId(rs.getString("ID"));
				vo1.setPassword(rs.getString("PASSWORD"));
				vo1.setName(rs.getString("Name"));
				vo1.setPID(rs.getInt("PID"));
			}
			return vo1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return null;

	}

	public boolean signUp(PersonVO vo) { // 회원가입
		conn = JDBCUtil.connect();
		try {
			pstmt=conn.prepareStatement(sql_signup);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			pstmt.setString(3, vo.getName());
			int a = pstmt.executeUpdate();
			if(a<=0) {
				System.out.println("회원가입 실패");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true;
		
	}

	public boolean Delete(PersonVO vo) { // 회원 탈퇴
		conn=JDBCUtil.connect();
		try {
			pstmt=conn.prepareStatement(sql_delete);
			pstmt.setString(1, vo.getName());
			pstmt.setString(2, vo.getPassword());
			int a = pstmt.executeUpdate();
			if(a<=0) {
				System.out.println("로그 :회원탈퇴 실패");
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		System.out.println("로그 : 회원가입 성공");
		return true;
		
	}
}
