package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RecentViewDAO {
	Connection conn;
	PreparedStatement pstmt;
	
	
	 // join() -> 조인된 테이블
	
	
	

	}
