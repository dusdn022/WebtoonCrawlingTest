package model;

public class RecentViewVO {
	private int rvpk; //허울뿐이 숫자만 세주는 pk
	private int pid; //사람
	private int wid; //웹툰PK
	
	public int getRvpk() {
		return rvpk;
	}
	public void setRvpk(int rvpk) {
		this.rvpk = rvpk;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getWid() {
		return wid;
	}
	public void setWid(int wid) {
		this.wid = wid;
	}
	

}
