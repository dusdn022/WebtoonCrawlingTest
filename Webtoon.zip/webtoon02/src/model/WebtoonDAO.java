package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WebtoonDAO {
	Connection conn;
	PreparedStatement pstmt;

	JDBCUtil jdbc = new JDBCUtil();

	final String sql_insert = "INSERT INTO WEBTOON (TITLE,IMG, AUTHOR, CNT) VALUES(?,?,?,?)";
	final String sql_delete = "Delete FROM WEBTOON WHERE WID = ? ";
	final String sql_update = "UPDATE WEBTOON SET CNT=CNT+1 WHERE WID=?";
	final String sql_selectOne = "SELECT * FROM WEBTOON WHERE title = ?";
	final String sql_selectAll = "SELECT * FROM WEBTOON WHERE TITLE LIKE '%'||?||'%' ORDER BY CNT DESC ";

	public boolean Insert(WebtoonVO vo) {
		conn = jdbc.connect();
		try {
			pstmt = conn.prepareStatement(sql_insert);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getImg());
			pstmt.setString(2, vo.getAuthor());
			pstmt.setInt(2, vo.getCnt());

			int a = pstmt.executeUpdate(); // c u d는 update() 그리고 select가 query()
			if (a <= 0) {
				System.out.println("로그 : 실패");
				return false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true;
	}

	public boolean Delete(WebtoonVO vo) {
		conn = JDBCUtil.connect();
		try {
			pstmt = conn.prepareStatement(sql_delete);
			pstmt.setInt(1, vo.getWid());
			int b = pstmt.executeUpdate();
			if (b <= 0) {
				System.out.println("로그 : 삭제실패");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true; // 성공
	}

	public boolean Update(WebtoonVO vo) {
		conn = JDBCUtil.connect();
		try {
			pstmt = conn.prepareStatement(sql_update);
			pstmt.setInt(1, vo.getWid());
			int c = pstmt.executeUpdate();
			if (c <= 0) {
				System.out.println("로그 : 조회 수행 실패");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}

		return true;

	}

	public WebtoonVO SelectOne(WebtoonVO vo) {
		conn = JDBCUtil.connect();
		try {
			pstmt = conn.prepareStatement(sql_selectOne);
			pstmt.setString(1, vo.getTitle());
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				WebtoonVO vo1 = new WebtoonVO();
				vo1.setAuthor(rs.getString("AUTHOR"));
				vo1.setCnt(rs.getInt("CNT"));
				vo1.setImg(rs.getString("IMG"));
				vo1.setTitle(rs.getString("TITLE"));
				return vo1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<WebtoonVO> SelectAll(WebtoonVO vo) {
		conn = JDBCUtil.connect();
		ArrayList<WebtoonVO> datas = new ArrayList<WebtoonVO>();
		try {
			pstmt = conn.prepareStatement(sql_selectAll);
			pstmt.setString(1, vo.getTitle());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				vo.setTitle(rs.getString("TITLE"));
				datas.add(vo);
			}
			return datas;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return null;

	}

}
